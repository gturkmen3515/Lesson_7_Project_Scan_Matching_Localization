You are reading the documentation of 2.2.0. 
If, for some reason you need the documentation of older versions, you can download them from this page.

  * [1.0.0](/archive/rpclib_docs_1.0.0.zip)
